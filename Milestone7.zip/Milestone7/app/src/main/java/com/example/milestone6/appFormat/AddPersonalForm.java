package com.example.milestone6.appFormat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import com.example.milestone6.R;

public class AddPersonalForm extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    
    final String TAG = "ContactListApplication";

    EditText et_name, et_phone, et_email, et_houseID, et_street, et_city,
                et_zip, et_DOB, et_description;
    ImageView iv_icon;
    Spinner spin_icons, spin_states;
    Button b_addPerson, b_cancelPersonal;

    int positionToEdit = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_personal_form);
        Log.d(TAG, "onCreate: Transfered Forms");
        Bundle incoming = getIntent().getExtras();
        findViewsById();
        setAdapters();
        checkIncoming(incoming);
    }

    @Override
    protected void onResume() {
        super.onResume();
        b_addPerson.setOnClickListener(view -> {
            Intent i = new Intent(view.getContext(), ConsoleApp.class);
            startActivity(addIntent(i));
        });

        b_cancelPersonal.setOnClickListener(view -> {
            Intent i = new Intent(view.getContext(), ConsoleApp.class);
            startActivity(i);
        });

    }

    private void findViewsById() {
        Log.d(TAG, "findViewsById: Initialized");
        et_name = (EditText) findViewById(R.id.et_name);
        et_phone = (EditText) findViewById(R.id.et_phone);
        et_email = (EditText) findViewById(R.id.et_email);
        et_houseID = (EditText) findViewById(R.id.et_houseID);
        et_street = (EditText) findViewById(R.id.et_street);
        et_city = (EditText) findViewById(R.id.et_city);
        et_zip = (EditText) findViewById(R.id.et_zipCode);
        et_DOB = (EditText) findViewById(R.id.et_DOB);
        et_description = (EditText) findViewById(R.id.et_description);
        Log.d(TAG, "findViewsById: Edit Texts Done");

        iv_icon = (ImageView) findViewById(R.id.iv_iconDisplay);

        spin_icons = (Spinner) findViewById(R.id.spin_icons);
        spin_states = (Spinner) findViewById(R.id.spin_states);
        Log.d(TAG, "findViewsById: Spinners Done");

        b_addPerson = (Button) findViewById(R.id.b_addPersonal);
        b_cancelPersonal = (Button) findViewById(R.id.b_cancelPersonal);
        Log.d(TAG, "findViewsById: Buttons Done");
    }

    private void setAdapters() {
        Log.d(TAG, "setAdapters: Initialized Method");
        ArrayAdapter<CharSequence> spinIconAdapter = ArrayAdapter.createFromResource(this, R.array.iconList,
                android.R.layout.simple_spinner_item);
        spinIconAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin_icons.setAdapter(spinIconAdapter);
        spin_icons.setOnItemSelectedListener(this);

        ArrayAdapter<CharSequence> spinStateAdapter = ArrayAdapter.createFromResource(this, R.array.statesList,
                android.R.layout.simple_spinner_item);
        spinStateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin_states.setAdapter(spinStateAdapter);
        Log.d(TAG, "setAdapters: finished method");
    }

    private Intent addIntent(Intent i) {
        String name = et_name.getText().toString();
        String phone = et_phone.getText().toString();
        String email = et_email.getText().toString();
        int iconNum = spin_icons.getSelectedItemPosition();
        String dob = et_DOB.getText().toString();
        String desc = et_description.getText().toString();
        int houseID = Integer.parseInt(et_houseID.getText().toString());
        String street = et_street.getText().toString();
        String city = et_city.getText().toString();
        String state = spin_states.getSelectedItem().toString();
        int zip = Integer.parseInt(et_zip.getText().toString());

        i.putExtra("name", name);
        i.putExtra("phone", phone);
        i.putExtra("email", email);
        i.putExtra("iconNum", iconNum);
        i.putExtra("dob", dob);
        i.putExtra("desc", desc);
        i.putExtra("houseID", houseID);
        i.putExtra("street", street);
        i.putExtra("city", city);
        i.putExtra("state", state);
        i.putExtra("zip", zip);
        i.putExtra("edited", positionToEdit);

        return i;
    }

    private void checkIncoming(Bundle incoming) {
        if (incoming != null) {
            String name = "", phone = "", email = "", street = "", city = "", state = "";
            int iconNum = 1, houseID = 9999, zip = 90009;
            String desc = "", dob = "";

            if(incoming.get("edited") != null)
                positionToEdit = incoming.getInt("edited");

            if (incoming.get("name") != null)
                name = incoming.getString("name");

            if (incoming.get("phone") != null)
                phone = incoming.getString("phone");

            if (incoming.get("email") != null)
                email = incoming.getString("email");

            if (incoming.get("street") != null)
                street = incoming.getString("street");

            if (incoming.get("city") != null)
                city = incoming.getString("city");

            if (incoming.get("state") != null)
                state = incoming.getString("state");

            if (incoming.get("iconNum") != null)
                iconNum = incoming.getInt("iconNum");

            if (incoming.get("houseID") != null)
                houseID = incoming.getInt("houseID");

            if (incoming.get("zip") != null)
                zip = incoming.getInt("zip");

            if (incoming.get("dob") != null)
                dob = incoming.getString("dob");

            if (incoming.get("desc") != null)
                desc = incoming.getString("desc");

            et_name.setText(name);
            et_phone.setText(phone);
            et_email.setText(email);
            et_DOB.setText(dob);
            et_description.setText(desc);
            et_zip.setText(Integer.toString(zip));
            et_houseID.setText(Integer.toString(houseID));
            et_street.setText(street);
            et_city.setText(city);
            spin_states.setSelection(getIndex(spin_states, state));
            spin_icons.setSelection(iconNum);

        }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        int[] iconNumSelections = {
                R.drawable.icon01, R.drawable.icon02, R.drawable.icon03, R.drawable.icon04, R.drawable.icon05,
                R.drawable.icon06, R.drawable.icon07, R.drawable.icon08, R.drawable.icon09, R.drawable.icon10,
                R.drawable.icon11, R.drawable.icon12, R.drawable.icon13, R.drawable.icon14, R.drawable.icon15,
                R.drawable.icon16, R.drawable.icon17, R.drawable.icon18, R.drawable.icon19, R.drawable.icon20,
                R.drawable.icon17, R.drawable.icon22, R.drawable.icon23, R.drawable.icon24, R.drawable.icon25,
                R.drawable.icon18, R.drawable.icon27, R.drawable.icon28, R.drawable.icon29, R.drawable.icon30
        };

        iv_icon.setImageResource(iconNumSelections[i]);

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    private int getIndex(Spinner spinner, String checkString) {
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(checkString))
                return i;
        }
        return 0;
    }
}