package com.example.milestone6.appFormat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.milestone6.*;
import com.example.milestone6.access.AddressBook;
import com.example.milestone6.access.FileAccessService;
import com.example.milestone6.contacts.BaseContact;
import com.example.milestone6.contacts.BusinessContact;
import com.example.milestone6.contacts.PersonContact;
import com.example.milestone6.supplemental.Location;


public class ConsoleApp extends AppCompatActivity {

    final String TAG = "ContactListApplication";

    ListView lv_contacts;
    Button b_search, b_addPersonal, b_addBusiness;
    EditText et_search;

    FileAccessService fas;
    AddressBook book;
    ContactAdapter contactAdapter;
    boolean createNew;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "Created");
        findViewsById();
        createNew = true;

    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "Started");

        Bundle incoming = getIntent().getExtras();

        fas = new FileAccessService(getApplicationContext());
        ((MyApp) this.getApplication()).setBook(fas.readAllContacts());
        book = ((MyApp) this.getApplication()).getBook();
        contactAdapter = new ContactAdapter(this, book);
        lv_contacts.setAdapter(contactAdapter);
        lv_contacts.setLongClickable(true);
        checkIncoming(incoming);

    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "Resumed");

        b_addPersonal.setOnClickListener(view -> {
            Intent i = new Intent(view.getContext(), AddPersonalForm.class);
            Log.d(TAG, "Created Intent");
            startActivity(i);
        });

        b_addBusiness.setOnClickListener(view -> {
            Intent i = new Intent(view.getContext(), AddBusinessForm.class);
            startActivity(i);
        });

        b_search.setOnClickListener(view -> {
            String searchFor = et_search.getText().toString();
            String searchButtonText = b_search.getText().toString();
            Log.d(TAG, "onResume: searchFor = " + searchFor);
            if (!searchFor.equals("") && !searchButtonText.equals("CLEAR")) {
                ContactAdapter searches = new ContactAdapter(this, new AddressBook(book.findContacts(searchFor)));
                lv_contacts.setAdapter(searches);
                b_search.setText("CLEAR");
            } else {
                book = fas.readAllContacts();
                lv_contacts.setAdapter(contactAdapter);
                b_search.setText("SEARCH");
                et_search.setText("");
            }
        });

        lv_contacts.setOnItemLongClickListener((adapterView, view, pos, l) -> {
            editPerson(pos);
            return true;
        });

        lv_contacts.setOnItemClickListener((adapterView, view, i, l) -> {
            Intent intent = new Intent(view.getContext(), ContactOptionsScreen.class);
            intent.putExtra("name", book.getContact(i).getName());
            intent.putExtra("phone", book.getContact(i).getPhone());
            intent.putExtra("email", book.getContact(i).getEmail());
            intent.putExtra("address", book.getContact(i).getAddress().toString());
            intent.putExtra("position", i);
            startActivity(intent);
        });

    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "Paused");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "Stopped");
        fas.saveAllContacts(book);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Destroyed");
    }

    private void findViewsById() {
        lv_contacts = (ListView) findViewById(R.id.lv_contacts);
        b_addBusiness = (Button) findViewById(R.id.b_addBContact);
        b_addPersonal = (Button) findViewById(R.id.b_addPContact);
        b_search = (Button) findViewById(R.id.b_search);
        et_search = (EditText) findViewById(R.id.et_searchBar);
    }

    private void checkIncoming(Bundle incoming) {
        if (incoming != null) {
            Log.d(TAG, "onStart: incoming != null: " + true);
            String name = "", phone = "", email = "", street = "", city = "", state = "";
            int iconNum = 1, houseID = 9999, zip = 90009, positionEdited = -1;

            String desc = "", dob = "", hours = "", url = "";

            if(incoming.get("edited") != null)
                positionEdited = incoming.getInt("edited");

            if (incoming.get("name") != null)
                name = incoming.getString("name");

            if (incoming.get("phone") != null)
                phone = incoming.getString("phone");

            if (incoming.get("email") != null)
                email = incoming.getString("email");

            if (incoming.get("street") != null)
                street = incoming.getString("street");

            if (incoming.get("city") != null)
                city = incoming.getString("city");

            if (incoming.get("state") != null)
                state = incoming.getString("state");

            if (incoming.get("iconNum") != null)
                iconNum = incoming.getInt("iconNum");

            if (incoming.get("houseID") != null)
                houseID = incoming.getInt("houseID");

            if (incoming.get("zip") != null)
                zip = incoming.getInt("zip");

            Location l = new Location(houseID, street, city, state, zip);

            if (incoming.get("dob") != null)
                dob = incoming.getString("dob");
            if (incoming.get("desc") != null)
                desc = incoming.getString("desc");

            if (incoming.get("hours") != null)
                hours = incoming.getString("hours");
            if (incoming.get("url") != null)
                url = incoming.getString("url");

            if (positionEdited > -1) {
                book.removeContact(positionEdited);
            }

            for (BaseContact b : book.getContacts()) {
                if (b.getName().equalsIgnoreCase(name) && b.getPhone().equalsIgnoreCase(phone)) {
                    Log.d(TAG, "onIf in forloop for name check: " + name + " = " + b.getName() + " & " + phone + " = " + b.getPhone());
                    createNew = false;
                }
            }

            if (!dob.equals("") && !desc.equals("") && createNew) {
                PersonContact p = new PersonContact(name, phone, l, iconNum, email, dob, desc);
                book.addContact(p);
                fas.saveAllContacts(book);
            }

            if (!hours.equals("") && !url.equals("") && createNew) {
                BusinessContact b = new BusinessContact(name, phone, l, iconNum, email, hours, url);
                book.addContact(b);
                fas.saveAllContacts(book);
            }
            incoming = null;
            contactAdapter.notifyDataSetChanged();

        }
    }


    private void editPerson(int pos) {
        Intent i;
        BaseContact c;
        if (book.getContact(pos) instanceof PersonContact) {
            i = new Intent(getApplicationContext(), AddPersonalForm.class);
            PersonContact p = (PersonContact) book.getContact(pos);
            i.putExtra("dob", p.getDOB());
            i.putExtra("desc", p.getDescription());
            c = p;
        }
        else {
            i = new Intent(getApplicationContext(), AddBusinessForm.class);
            BusinessContact b = (BusinessContact) book.getContact(pos);
            i.putExtra("hours", b.getHours());
            i.putExtra("url", b.getWebsite());
            c = b;
        }

        i.putExtra("name", c.getName());
        i.putExtra("phone", c.getPhone());
        i.putExtra("email", c.getEmail());
        i.putExtra("iconNum", c.getIconNum());
        i.putExtra("houseID", c.getAddress().getHouseID());
        i.putExtra("street", c.getAddress().getStreet());
        i.putExtra("city", c.getAddress().getCity());
        i.putExtra("state", c.getAddress().getState());
        i.putExtra("zip", c.getAddress().getZipCode());
        i.putExtra("edited", pos);

        startActivity(i);
    }

}