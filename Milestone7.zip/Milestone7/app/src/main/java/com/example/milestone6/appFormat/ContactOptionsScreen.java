package com.example.milestone6.appFormat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.milestone6.R;

public class ContactOptionsScreen extends AppCompatActivity {

    TextView tv_contactName;
    ImageButton b_sendToEmail, b_sendToMaps, b_sendToDialer, b_sendToSMS, b_deleteContact;
    Button b_back;

    String name = "", phone = "", email = "", address = "";
    int position = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_options_screen);
        findViewsByID();
        Bundle incoming = getIntent().getExtras();

        if (incoming != null) {
            if (incoming.get("name") != null)
                name = incoming.getString("name");
            if (incoming.get("phone") != null)
                phone = incoming.getString("phone");
            if (incoming.get("email") != null)
                email = incoming.getString("email");
            if (incoming.get("address") != null)
                address = incoming.getString("address");
            if (incoming.get("position") != null) {
                position = incoming.getInt("position");
            }
        }

        tv_contactName.setText(name + "?");

    }

    @Override
    protected void onResume() {
        super.onResume();

        b_back.setOnClickListener(view -> {
            Intent i = new Intent(view.getContext(), ConsoleApp.class);
            startActivity(i);
        });

        b_deleteContact.setOnClickListener(view -> {
            Intent i = new Intent(view.getContext(), ConsoleApp.class);
            i.putExtra("edited", position);
            startActivity(i);
        });

        b_sendToEmail.setOnClickListener(view -> {
            String[] emails = {email};
            Intent emailing = new Intent(Intent.ACTION_SENDTO);
            emailing.setData(Uri.parse("mailto:"));
            emailing.putExtra(Intent.EXTRA_EMAIL, emails);
            emailing.putExtra(Intent.EXTRA_SUBJECT, "Dear " + name);
            if (emailing.resolveActivity(getPackageManager()) != null)
                startActivity(emailing);
        });

        b_sendToDialer.setOnClickListener(view -> {
            Intent dialer = new Intent(Intent.ACTION_DIAL);
            dialer.setData(Uri.parse("tel:" + phone));
            if (dialer.resolveActivity(getPackageManager()) != null)
                startActivity(dialer);
        });

        b_sendToSMS.setOnClickListener(view -> {
            Intent sms = new Intent(Intent.ACTION_SENDTO);
            sms.setData(Uri.parse("smsto:" + phone));
            if (sms.resolveActivity(getPackageManager()) != null)
                startActivity(sms);
        });

        b_sendToMaps.setOnClickListener(view -> {
            Intent maps = new Intent(Intent.ACTION_VIEW);
            maps.setData(Uri.parse("geo:0,0?q=" + address));
            if (maps.resolveActivity(getPackageManager()) != null)
                startActivity(maps);
        });

    }

    private void findViewsByID() {
        tv_contactName = (TextView) findViewById(R.id.tv_contactName);
        b_sendToEmail = (ImageButton) findViewById(R.id.b_sendToEmail);
        b_sendToDialer = (ImageButton) findViewById(R.id.b_sendToDialer);
        b_sendToMaps = (ImageButton) findViewById(R.id.b_sendToMaps);
        b_sendToSMS = (ImageButton) findViewById(R.id.b_sendToSMS);
        b_deleteContact = (ImageButton) findViewById(R.id.b_deleteContact);
        b_back = (Button) findViewById(R.id.b_back);
    }
}