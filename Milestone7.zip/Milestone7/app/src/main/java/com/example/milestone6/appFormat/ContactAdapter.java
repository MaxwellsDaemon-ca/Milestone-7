package com.example.milestone6.appFormat;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.milestone6.R;
import com.example.milestone6.access.AddressBook;
import com.example.milestone6.contacts.BaseContact;

public class ContactAdapter extends BaseAdapter {

    Activity myActivity;
    AddressBook book;

    public ContactAdapter(Activity myActivity, AddressBook book) {
        this.myActivity = myActivity;
        this.book = book;
    }

    @Override
    public int getCount() {
        return book.getContacts().size();
    }

    @Override
    public BaseContact getItem(int i) {
        return book.getContact(i);
    }

    @Override
    public long getItemId(int i) {
        return book.getContact(i).getContactID();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        View contactLayout;
        LayoutInflater inflater = (LayoutInflater) myActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        contactLayout = inflater.inflate(R.layout.contact_list_layout, viewGroup, false);

        TextView tv_name = contactLayout.findViewById(R.id.tv_contactName);
        TextView tv_phone = contactLayout.findViewById(R.id.tv_contactPhoneNum);
        ImageView iv_icon = contactLayout.findViewById(R.id.iv_contactIcon);

        BaseContact b = this.getItem(i);

        tv_name.setText(b.getName());
        tv_phone.setText(b.getPhone());

        int[] iconResNums = {
                R.drawable.icon01, R.drawable.icon02, R.drawable.icon03, R.drawable.icon04,
                R.drawable.icon05, R.drawable.icon06, R.drawable.icon07, R.drawable.icon08,
                R.drawable.icon09, R.drawable.icon10, R.drawable.icon11, R.drawable.icon12,
                R.drawable.icon13, R.drawable.icon14, R.drawable.icon15, R.drawable.icon16,
                R.drawable.icon17, R.drawable.icon18, R.drawable.icon19, R.drawable.icon20,
                R.drawable.icon21, R.drawable.icon22, R.drawable.icon23, R.drawable.icon24,
                R.drawable.icon25, R.drawable.icon26, R.drawable.icon27, R.drawable.icon28,
                R.drawable.icon29, R.drawable.icon30
        };

        iv_icon.setImageResource(iconResNums[b.getIconNum()]);

        return contactLayout;
    }
}
