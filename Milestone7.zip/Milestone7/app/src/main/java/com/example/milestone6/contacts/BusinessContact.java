package com.example.milestone6.contacts;

import com.example.milestone6.supplemental.Location;
import com.example.milestone6.supplemental.Photo;

import java.io.Serializable;

/**
 * Subclass of BaseContact, specified for business contacts
 * @author Chauncey
 */
public class BusinessContact extends BaseContact implements Serializable {

    private String hours, website;

    /**
     * Default Constructor, generates fake contact
     */
    public BusinessContact() {
        super();
        this.hours = "";
        this.website = "";
    }

    /**
     * Non-default constructor, takes in only name and phone
     * @param name the name of the business
     * @param phone the phone of the business
     */
    public BusinessContact(String name, String phone) {
        super(name, phone);
        this.hours = "";
        this.website = "";
    }

    /**
     * Non-default constructor, takes in name, phone, address, business hours, and website url.
     * @param name the name of the business
     * @param phone the phone of the business
     * @param address the address of the business
     * @param hours the hours of the business
     * @param website the URL of the business
     */
    public BusinessContact(String name, String phone, Location address, int iconNum, String email, String hours, String website) {
        super(name, phone, address, iconNum, email);
        this.hours = hours;
        this.website = website;
    }

    /**
     * Non-default constructor, takes in name, phone, address, photo, business hours, and website url.
     * @param name the name of the business
     * @param phone the phone of the business
     * @param address the address of the business
     * @param photo the logo or storefront picture of the business
     * @param hours the hours of the business
     * @param website the URL of the business
     */
    public BusinessContact(String name, String phone, Location address, String email, Photo photo, String hours, String website) {
        super(name, phone, address, email, photo);
        this.hours = hours;
        this.website = website;
    }

    /**
     * Getter for the business hours
     * @return the hours
     */
    public String getHours() {
        return hours;
    }

    /**
     * Setter for the business hours
     * @param hours the hours to set
     */
    public void setHours(String hours) {
        this.hours = hours;
    }

    /**
     * Getter for the URL of the website
     * @return the URL
     */
    public String getWebsite() {
        return website;
    }

    /**
     * Setter for the URL of the website
     * @param website the URL to set
     */
    public void setWebsite(String website) {
        this.website = website;
    }

    @Override
    public String toString() {
        return String.format("ID: %d%nName: %s%nPhone: %s%nAddress:%n%s%nBusiness Hours: %s%nWebsite URL:%n%s", contactID, name, phone, address.toString(), hours, website);
    }

    @Override
    public String searchString() {
        return String.format("%s %s %s %s %s %s %s", contactID, name, phone, address.toString(), email, hours, website);
    }

}
