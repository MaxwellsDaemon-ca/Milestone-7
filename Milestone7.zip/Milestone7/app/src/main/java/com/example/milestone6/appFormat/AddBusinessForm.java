package com.example.milestone6.appFormat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import com.example.milestone6.R;

public class AddBusinessForm extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    EditText et_name, et_phone, et_email, et_houseID, et_street, et_city,
            et_zip, et_hours, et_url;
    ImageView iv_icon;
    Spinner spin_icons, spin_states;
    Button b_addBusiness, b_cancelBusiness;

    int positionToEdit = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_business_form);
        Bundle incoming = getIntent().getExtras();
        findViewsById();
        setAdapters();
        checkIncoming(incoming);
    }

    @Override
    protected void onResume() {
        super.onResume();
        b_addBusiness.setOnClickListener(view -> {
            Intent i = new Intent(view.getContext(), ConsoleApp.class);
            startActivity(addIntent(i));
        });

        b_cancelBusiness.setOnClickListener(view -> {
            Intent i = new Intent(view.getContext(), ConsoleApp.class);
            startActivity(i);
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        int[] iconNumSelections = {
                R.drawable.icon01, R.drawable.icon02, R.drawable.icon03, R.drawable.icon04, R.drawable.icon05,
                R.drawable.icon06, R.drawable.icon07, R.drawable.icon08, R.drawable.icon09, R.drawable.icon10,
                R.drawable.icon11, R.drawable.icon12, R.drawable.icon13, R.drawable.icon14, R.drawable.icon15,
                R.drawable.icon16, R.drawable.icon17, R.drawable.icon18, R.drawable.icon19, R.drawable.icon20,
                R.drawable.icon17, R.drawable.icon22, R.drawable.icon23, R.drawable.icon24, R.drawable.icon25,
                R.drawable.icon18, R.drawable.icon27, R.drawable.icon28, R.drawable.icon29, R.drawable.icon30
        };

        iv_icon.setImageResource(iconNumSelections[i]);
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    private void findViewsById() {
        et_name = (EditText) findViewById(R.id.et_name);
        et_phone = (EditText) findViewById(R.id.et_phone);
        et_email = (EditText) findViewById(R.id.et_email);
        et_houseID = (EditText) findViewById(R.id.et_houseID);
        et_street = (EditText) findViewById(R.id.et_street);
        et_city = (EditText) findViewById(R.id.et_city);
        et_zip = (EditText) findViewById(R.id.et_zipCode);
        et_hours = (EditText) findViewById(R.id.et_hours);
        et_url = (EditText) findViewById(R.id.et_url);

        iv_icon = (ImageView) findViewById(R.id.iv_iconDisplay);

        spin_icons = (Spinner) findViewById(R.id.spin_icons);
        spin_states = (Spinner) findViewById(R.id.spin_states);

        b_addBusiness = (Button) findViewById(R.id.b_addBusiness);
        b_cancelBusiness = (Button) findViewById(R.id.b_cancelBusiness);
    }

    private void setAdapters() {
        ArrayAdapter<CharSequence> spinIconAdapter = ArrayAdapter.createFromResource(this, R.array.iconList,
                android.R.layout.simple_spinner_item);
        spinIconAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin_icons.setAdapter(spinIconAdapter);
        spin_icons.setOnItemSelectedListener(this);

        ArrayAdapter<CharSequence> spinStateAdapter = ArrayAdapter.createFromResource(this, R.array.statesList,
                android.R.layout.simple_spinner_item);
        spinStateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin_states.setAdapter(spinStateAdapter);
    }

    private Intent addIntent(Intent i) {
        String name = et_name.getText().toString();
        String phone = et_phone.getText().toString();
        String email = et_email.getText().toString();
        int iconNum = Integer.parseInt(spin_icons.getSelectedItem().toString());
        String hours = et_hours.getText().toString();
        String url = et_url.getText().toString();
        int houseID = Integer.parseInt(et_houseID.getText().toString());
        String street = et_street.getText().toString();
        String city = et_city.getText().toString();
        String state = spin_states.getSelectedItem().toString();
        int zip = Integer.parseInt(et_zip.getText().toString());

        i.putExtra("name", name);
        i.putExtra("phone", phone);
        i.putExtra("email", email);
        i.putExtra("iconNum", iconNum);
        i.putExtra("hours", hours);
        i.putExtra("url", url);
        i.putExtra("houseID", houseID);
        i.putExtra("street", street);
        i.putExtra("city", city);
        i.putExtra("state", state);
        i.putExtra("zip", zip);
        i.putExtra("edited", positionToEdit);

        return i;
    }

    private void checkIncoming(Bundle incoming) {
        if (incoming != null) {
            String name = "", phone = "", email = "", street = "", city = "", state = "";
            int iconNum = 1, houseID = 9999, zip = 90009;
            String hours = "", url = "";

            if (incoming.get("edited") != null)
                positionToEdit = incoming.getInt("edited");

            if (incoming.get("name") != null)
                name = incoming.getString("name");

            if (incoming.get("phone") != null)
                phone = incoming.getString("phone");

            if (incoming.get("email") != null)
                email = incoming.getString("email");

            if (incoming.get("street") != null)
                street = incoming.getString("street");

            if (incoming.get("city") != null)
                city = incoming.getString("city");

            if (incoming.get("state") != null)
                state = incoming.getString("state");

            if (incoming.get("iconNum") != null)
                iconNum = incoming.getInt("iconNum");

            if (incoming.get("houseID") != null)
                houseID = incoming.getInt("houseID");

            if (incoming.get("zip") != null)
                zip = incoming.getInt("zip");

            if (incoming.get("url") != null)
                url = incoming.getString("url");

            if (incoming.get("hours") != null)
                hours = incoming.getString("hours");

            et_name.setText(name);
            et_phone.setText(phone);
            et_email.setText(email);
            et_hours.setText(hours);
            et_url.setText(url);
            et_zip.setText(Integer.toString(zip));
            et_houseID.setText(Integer.toString(houseID));
            et_street.setText(street);
            et_city.setText(city);
            spin_states.setSelection(getIndex(spin_states, state));
            spin_icons.setSelection(iconNum);

        }
    }

    private int getIndex(Spinner spinner, String checkString) {
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(checkString))
                return i;
        }
        return 0;
    }
}