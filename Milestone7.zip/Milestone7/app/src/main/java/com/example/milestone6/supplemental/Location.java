package com.example.milestone6.supplemental;

import java.io.Serializable;

/**
 * Supplemental class for Location object.
 * @author Chauncey
 */
public class Location implements Serializable {

    private int houseID, zipCode;
    private String street, city, state;

    /**
     * Default constructor. Makes a fake address
     */
    public Location() {
        this.houseID = 9999;
        this.street = "Example St";
        this.city = "City";
        this.state = "XX";
        this.zipCode = 90009;
    }

    /**
     * Non-Default constructor. Takes in all parts of an address
     * @param houseID the identifier for a house on a street
     * @param street the street name
     * @param city the city name
     * @param state the state name
     * @param zip the zip code
     */
    public Location(int houseID, String street, String city, String state, int zip) {
        this.houseID = houseID;
        this.street = street;
        this.city = city;
        this.state = state;
        this.zipCode = zip;
    }

    /**
     * Getter for hosue ID
     * @return the houseID
     */
    public int getHouseID() {
        return houseID;
    }

    /**
     * Setter for house ID
     * @param houseID the houseID to set
     */
    public void setHouseID(int houseID) {
        this.houseID = houseID;
    }

    /**
     * Getter for zip code
     * @return the zipCode
     */
    public int getZipCode() {
        return zipCode;
    }

    /**
     * Setter for zip code
     * @param zipCode the zipCode to set
     */
    public void setZipCode(int zipCode) {
        this.zipCode = zipCode;
    }

    /**
     * Getter for street
     * @return the street
     */
    public String getStreet() {
        return street;
    }

    /**
     * Setter for street
     * @param street the street to set
     */
    public void setStreet(String street) {
        this.street = street;
    }

    /**
     * Getter for city
     * @return the city
     */
    public String getCity() {
        return city;
    }

    /**
     * Setter for city
     * @param city the city to set
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * Getter for state
     * @return the state
     */
    public String getState() {
        return state;
    }

    /**
     * Setter for state
     * @param state the state to set
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * Overridden toString()
     * @return formatted location string
     */
    @Override
    public String toString() {
        return String.format("%d %s, %s, %s %d", houseID, street, city, state, zipCode);
    }



}

